import urllib.request
import json
import pymongo
from collections import defaultdict,OrderedDict
from flask import Flask, render_template
import pandas as pd 
import numpy as np 
app = Flask(__name__)

# # The data can come from anywhere you can read it; for instance, a SQL
# # query or a file on the filesystem created by another script.
# # This example expects two values per row; for more complicated examples,
# # refer to the Google Charts gallery.
# myclient = pymongo.MongoClient("mongodb://localhost:27017/")
# mydb = myclient["BDMT1004_job_db"]#create database
# mycol = mydb["job_counts"] # create collection

# # for jobType in jobTypeList:
# #    with urllib.request.urlopen('https://jobs.search.gov/jobs/search.json?query=%s+jobs'%jobType) as url:
# #       jobdata = json.loads(url.read().decode())
# #       mycol.insert_many(jobdata)


# # retrieve data from database




@app.route('/graph/')
def hello():

   # retrieve data from database
   myclient = pymongo.MongoClient("mongodb://localhost:27017/")
   mydb = myclient["BDMT1004_job_db"]#database
   mycol = mydb["job_counts"] #collection


# group data for making chart
#### sort by job counts and location

   titleList = []
   locationList = []
   maximumList = []
   minimumList = []
   midList = []

   for row in mycol.find():
      ## only consider jobs for which the pay is given as annual salary, do not include part time jobs
      if row['maximum'] < 30000:
         continue
      for location in row['locations']:

         
         title = row['position_title'].lower()
         if 'nurse' in title or 'physician' in title:
            titleList.append('Medical Service')
         elif 'financ' in title:
            titleList.append('Finance')
         elif 'tech' in title:
            titleList.append('Technician')
         elif 'engineer' in title:
            titleList.append('Engineer')
         elif 'professor' in title or 'instructor' in title:
            titleList.append('Education')
         elif 'sale' in title or 'market' in title:
            titleList.append('Marketing')
         else:
            continue
         
         maximumList.append(row['maximum'])
         minimumList.append(row['minimum'])
         midList.append( (row['maximum'] + row['minimum'])*0.5 )
         locationList.append(location.split(",")[-1].strip())

   jobDF = pd.DataFrame({'Title': titleList, 'Location':locationList, 'Max':maximumList, 'Min':minimumList, 'Mid':midList})

   # top 3 job title
   topTitle =  list( jobDF.groupby(['Title']).count().sort_values(by='Location', ascending=False).index[0:3] ) 
   # top 5 state
   topLoc =  list( jobDF.groupby(['Location']).count().sort_values(by='Title', ascending=False).index[0:5] ) 

   #filter data when job = top 3 job and state = top 5 state
   jobSubDF = jobDF.loc[ (jobDF['Title'].isin(topTitle)) & (jobDF['Location'].isin(topLoc)) ]


   #create a pivot table for avg salary in top 5 states and top 3 jobs
   piv_talbe = pd.pivot_table(jobSubDF, values='Max', index=['Location'],columns=['Title'], aggfunc=np.mean).reset_index()

   
   piv_talbe = piv_talbe.fillna(0) #replace the na with 0


   salary_input  = []
   for x in piv_talbe.as_matrix():
      salary_input.append(tuple(x))




   #locationInputData =[(key, locationCountsSorted[key]) for key in list(locationCountsSorted)[0:topN] ]
   #print(locationInputData)
   #locationInputData = [('CA', 103, 200,300), ('UT', 100,0,400)]
   # return render_template('Barchart.html', data=data)
   col_one = "State"
   col_two = topTitle[0]
   col_three = topTitle[1]
   col_four = topTitle[2]

   return render_template('Salary.html', colOne = col_one, colTwo = col_two, colThree = col_three, colFour = col_four, statedata=salary_input)
   #return render_template('Barchart.html', statedata=locationInputData)
if __name__ == '__main__':
	# Automatically detect changes to charts.py and reload the server as
	# necessary.
	app.run(debug=True) 