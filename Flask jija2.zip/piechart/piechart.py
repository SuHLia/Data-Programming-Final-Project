import urllib.request
import json
import pymongo
from collections import defaultdict
from flask import Flask, render_template
app = Flask(__name__)

# jobTypeList = ['physician', 'nursing', 'financial' , 'technician', 'technologist', 'Engineer', 'professor', 'instructor',  'sales', 'marketing']

# myclient = pymongo.MongoClient("mongodb://localhost:27017/")
# mydb = myclient["BDMT1004_job_db"]#create database
# mycol = mydb["job_counts"] # create collection

# # for jobType in jobTypeList:
# #    with urllib.request.urlopen('https://jobs.search.gov/jobs/search.json?query=%s+jobs'%jobType) as url:
# #       jobdata = json.loads(url.read().decode())
# #       mycol.insert_many(jobdata)


@app.route('/chart/')
def hello():
	# The data can come from anywhere you can read it; for instance, a SQL
	# query or a file on the filesystem created by another script.
	# This example expects two values per row; for more complicated examples,
	# refer to the Google Charts gallery.
   # retrieve data from database
   myclient = pymongo.MongoClient("mongodb://localhost:27017/")
   mydb = myclient["BDMT1004_job_db"]# database
   mycol = mydb["job_counts"] #  collection


   # group data for making chart
   jobCounts = defaultdict(int)

   for row in mycol.find():
      title = row['position_title'].lower()
      if 'nurse' in title or 'physician' in title:
         jobCounts['Medical Service'] += 1
      elif 'financ' in title:
         jobCounts['Finance'] += 1
      elif 'tech' in title:
         jobCounts['Technician'] += 1
      elif 'engineer' in title:
         jobCounts['Engineer'] += 1
      elif 'professor' in title or 'instructor' in title:
         jobCounts['Education'] += 1
      elif 'sale' in title or 'market' in title:
         jobCounts['Marketing'] += 1
      else:
         pass 


   #jobCountsInput = [('Teacher', 48), ('Driver', 27), ('Doctor', 32), ('Advisor', 42), ("IT", 100) ]
   jobCountsInput = [(key, value) for key,value in jobCounts.items()]
   print(jobCountsInput)

   # return render_template('template.html', data=data)
   return render_template('piechart.html', data=jobCountsInput)

if __name__ == '__main__':
	# Automatically detect changes to charts.py and reload the server as
	# necessary.
	app.run(debug=True) 